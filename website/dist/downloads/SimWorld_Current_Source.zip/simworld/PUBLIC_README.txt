SimWorld engine source and documentation snapshot.
Detailed phase plans cover 0–15. Phase 16 is a roadmap outline. The implemented engine remains the reduced physics_build 0.1 baseline.
Use Python 3.11.9; install requirements.txt, run python -m pytest -q, then python -m sim.demo --seed 42 --ticks 3400 --cells 8 --probe-cells 2,3 --out run_demo.
The complete repository, including website tooling, is https://github.com/enderPeer/simworld.
No software license has been selected; public availability does not itself grant a license.
