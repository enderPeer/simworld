SimWorld engine source and documentation snapshot.
Detailed phase plans cover 0–16. All seventeen phases have detailed plans; implementation status is separate. The implemented engine remains the reduced physics_build 0.1 baseline.
For new development, read DEVELOPMENT_SPEC.md and run python scripts/check_development_spec.py --ready. The first ticket is D0-01.
The referenced historical audit archive and CI workflow are included as planning inputs.
Use Python 3.11.9; install requirements.txt, run python -m pytest -q, then python -m sim.demo --seed 42 --ticks 3400 --cells 8 --probe-cells 2,3 --out run_demo.
The complete repository, including website tooling, is https://github.com/enderPeer/simworld.
No software license has been selected; public availability does not itself grant a license.
