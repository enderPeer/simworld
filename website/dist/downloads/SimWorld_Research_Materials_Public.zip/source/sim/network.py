"""BBN reaction network over per-cell nuclide counts (BUILD0 tick step 5).

Explicit demo-level network: channels come from the bind.py registry
(Q > 0 under the fitted binding formula), forward rates are
C_cap * S_ij * n_i * n_j / V with Gamow suppression exp(-G Z_i Z_j /
T^(1/3)) for charged pairs, and photodisintegration runs through the
same channels by detailed balance, k_rev = k_fwd * (g_i g_j / g_C) *
(mu T phi)^(3/2) * exp(-B_C / T) with g = A. Carriers couple to the heat
bath (the detailed-balance factors), not to rows. Nuclides are keyed by
(Z, A); no element names appear anywhere in sim/.
"""

import math

import numpy as np

from . import bind, constants as C, nucbind

_H_RATE = math.log(C.EXPANSION_RATE) / 2.0

SPECIES = [(Z, A) for Z in range(C.NUC_Z_MAX + 1)
           for A in range(1, C.NUC_A_MAX + 1) if Z <= A]
IDX = {k: i for i, k in enumerate(SPECIES)}


class NucStore:
    def __init__(self, cells):
        self.cells = int(cells)
        self.counts = np.zeros((len(SPECIES), self.cells), dtype=np.int64)

    def add(self, cell, Z, A, k=1):
        self.counts[IDX[(Z, A)], cell] += int(k)

    def totals(self):
        return self.counts.sum(axis=1)

    def columns(self):
        return [self.counts.T.reshape(-1).astype(np.float64)]


def _gamow(Zi, Zj, T):
    if Zi == 0 or Zj == 0:
        return 1.0
    return math.exp(-C.GAMOW_G * Zi * Zj / T ** (1.0 / 3.0))


def _rates(nuc, cell, T):
    """Sample-order list of (i, j, kC, R_fwd, R_rev) for channels present."""
    counts = nuc.counts[:, cell]
    out = []
    nch = 0
    for ia in range(len(SPECIES)):
        ni = int(counts[ia])
        if ni <= 0:
            continue
        Zi, Ai = SPECIES[ia]
        for ib in range(ia, len(SPECIES)):
            nj = int(counts[ib])
            if nj <= 0:
                continue
            Zj, Aj = SPECIES[ib]
            Zs, As = Zi + Zj, Ai + Aj
            if As > C.NUC_A_MAX or Zs > C.NUC_Z_MAX:
                continue
            if not bind.channel_open(Zi, Ai, Zj, Aj):
                continue
            nf = ni * (nj - 1) if ia == ib else ni * nj
            kfwd = C.C_CAP * _gamow(Zi, Zj, T) * nf / C.V_CELL
            mu = Ai * Aj / As
            Bc = nucbind.binding(Zs, As)
            krev = (C.C_CAP / C.V_CELL * (Ai * Aj / As)
                    * (mu * T * C.SAHA_PHI) ** 1.5
                    * math.exp(-Bc / T) * int(counts[IDX[(Zs, As)]]))
            out.append((ia, ib, IDX[(Zs, As)], kfwd, krev))
            nch += 1
    return out


def _prob(rate):
    if rate <= 0.0:
        return 0.0
    return min(0.9, 1.0 - math.exp(-rate))


def step(nuc, ctx, tick, cell, T, sub=2):
    """One stochastic network tick for one cell. Returns reactions run."""
    ch = _rates(nuc, cell, T)
    if not ch:
        return 0
    r = ctx.draws(tick, "react", cell=cell, sub=sub, n=2 * len(ch),
                  payload=[float(len(ch)), float(T)], cause="network")
    counts = nuc.counts[:, cell]
    fired = 0
    for j, (ia, ib, kc, kf, kr) in enumerate(ch):
        if r[2 * j] < _prob(kf) and counts[ia] > 0 and counts[ib] > (1 if ia == ib else 0):
            counts[ia] -= 1
            counts[ib] -= 1
            counts[kc] += 1
            fired += 1
        elif r[2 * j + 1] < _prob(kr) and counts[kc] > 0:
            counts[kc] -= 1
            counts[ia] += 1
            counts[ib] += 1
            fired += 1
    return fired


JUMP_MAX_PROB = 1e-8  # every channel, in probability per tick, must sit
                      # below this for a jump span (all rates fall with T,
                      # so the jump-time value is the worst case)


def jump_quiet(nuc, cell, T):
    """True when no channel can fire during a whole jump span."""
    for ia, ib, kc, kf, kr in _rates(nuc, cell, T):
        if _prob(kf) >= JUMP_MAX_PROB or _prob(kr) >= JUMP_MAX_PROB:
            return False
    return True
