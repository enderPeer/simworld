"""M3 bind: baryon rule + channel registry + nucleon formation (BUILD0).

The baryon rule is table data, not branching code: stable baryons are the
three-quark multisets over the two confined flavors that contain both
flavors (weak equilibrium has sampled every flavor; one-flavor lumps do
not screen) and carry total charge 0 or +1 -- exactly two stable baryon
charges, and one massless carrier in the field table.

The reaction registry caches which (i, j) channels are open (Q > 0 under
the fitted binding formula). It is a pure cache: clearing it re-derives
identical answers, so cache-off replay hashes are identical.

Nucleon formation below Lambda_conf consumes confined quanta in triples;
the flavor label is drawn from the frozen weak-equilibrium ratio (the
confining field completes the flavor content -- sea completion, logged
as a demo-level simplification in the surprises ledger).
"""

import itertools

from . import nucbind
from .fields import CHARGE, FIELDS, MASS

QUARK_IDS = (0, 1)


def _quark_name(sid):
    return FIELDS[sid][1]


def stable_baryons():
    out = []
    for combo in itertools.combinations_with_replacement(QUARK_IDS, 3):
        if len(set(combo)) < 2:
            continue  # one-flavor lumps do not screen
        q = round(sum(CHARGE[s] for s in combo))
        if q in (0, 1):
            out.append((q, tuple(_quark_name(s) for s in combo)))
    return sorted(out)


def massless_carriers():
    return [f[1] for f in FIELDS if f[2] == 0.0]


# -- channel registry (pure cache) ----------------------------------------

_REGISTRY = {}


def _unbound(Zs, As):
    """Engine-level stability rules beyond the liquid drop: no mass-5
    nuclei (the A=5 gap that stalls BBN), and nothing past the N = Z +- 1
    drip edges (kills the diproton and neutron-rich leaks the fit gives).
    """
    Ns = As - Zs
    return As == 5 or abs(Ns - Zs) > 1


def channel(Z1, A1, Z2, A2):
    key = ((Z1, A1), (Z2, A2)) if (Z1, A1) <= (Z2, A2) else ((Z2, A2), (Z1, A1))
    hit = _REGISTRY.get(key)
    if hit is not None:
        return hit
    (Za, Aa), (Zb, Ab) = key
    Zs, As = Za + Zb, Aa + Ab
    gap = -1.0 if _unbound(Zs, As) else (
        nucbind.binding(Zs, As) - nucbind.binding(Za, Aa)
        - nucbind.binding(Zb, Ab))
    _REGISTRY[key] = gap
    return gap


def channel_open(Z1, A1, Z2, A2):
    return channel(Z1, A1, Z2, A2) > 0.0


def clear_registry():
    _REGISTRY.clear()


def registry_size():
    return len(_REGISTRY)


# -- nucleon formation ------------------------------------------------------

def bind_nucleons(store, ctx, tick, cell, p_neutron, sub=1):
    """Consume confined quanta in triples below Lambda_conf.

    Returns (n_neutrons, n_protons, n_quanta_left). Labels are drawn from
    the frozen weak ratio; triples consume any available flavors (sea
    completion). Emits into the thermal bath, not rows: the gluon/photon
    carriers of the binding couple to the heat bath that the network's
    detailed-balance terms already carry.
    """
    pu, pd = store.superposed_pool(cell, 0), store.superposed_pool(cell, 1)
    cu, cd = store.collapsed_pool(cell, 0), store.collapsed_pool(cell, 1)
    total = len(pu) + len(pd) + len(cu) + len(cd)
    n_bar = total // 3
    r = ctx.draws(tick, "react", cell=cell, sub=sub, n=n_bar,
                  payload=[float(p_neutron)], cause="bind")
    neutrons = 0
    for j in range(n_bar):
        for _ in range(3):
            _pop_any(store, cell)
        if r[j] < p_neutron:
            neutrons += 1
    left = (len(pu) + len(pd) + len(cu) + len(cd))
    return neutrons, n_bar - neutrons, left


def _pop_any(store, cell):
    for sp in (1, 0):
        pool = store.superposed_pool(cell, sp)
        if pool:
            store.remove_superposed_at(cell, sp, len(pool) - 1)
            return
        cpool = store.collapsed_pool(cell, sp)
        if cpool:
            store.remove_collapsed_at(cell, sp, len(cpool) - 1)
            return
