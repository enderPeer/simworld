SimWorld research white paper v1.1 — 29 October 2026

source/: current engine and detailed phase plans at 4134abddc30940f455209c442afe68f442ebaa75.
baseline_source/: original public audit source, including archived M3/M4 references.
research/: current manuscript, all 17 profiles, renderer, publication status, current/baseline manifests and preserved original audit evidence.

Engine: cd source; use Python 3.11.9; pip install -r requirements.txt; python -m pytest -q.
Historical diagnostics (from this archive root): python research/audit_diagnostics.py --source-root baseline_source --output-dir reproduced_audit
Paper: install research/requirements.txt, then python research/build.py --output reconstructed.pdf. See research/README.md for font and visual verification requirements.

The original simulation measurements were not repeated for this publication revision. Later Windows/Linux CI results and their URLs are recorded separately. Preserved historical audit notes describe their original snapshot; current source comments now explain the same unresolved mechanisms more accurately.
The complete repository and published paper are available at https://github.com/enderPeer/simworld and https://enderpeer.github.io/simworld/.
