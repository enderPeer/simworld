SimWorld research white paper materials, 29 October 2026

source/: exact source snapshot and archived M3/M4 run data.
research/: manuscript, audits, references, fresh run, source SHA-256 manifest.
Engine reproduction: cd source; use Python 3.11.9; pip install -r requirements.txt; python -m pytest -q; python -m sim.demo --seed 42 --ticks 3400 --cells 8 --probe-cells 2,3 --out reproduced_m4; python -m sim.replay reproduced_m4.
Audit diagnostic: from the archive root, run python research/audit_diagnostics.py --source-root source --output-dir reproduced_audit. This creates fresh evidence.
PDF source: manuscript.json holds editable text and tables. Run python research/build_whitepaper.py to render it using ReportLab and Windows Times New Roman/Arial. On another operating system, adjust the font paths in the builder. The optional write_manuscript.py regenerates manuscript.json from its prose source and would replace edits.
No new physics or engine fixes are included. Run timings are single-machine observations.
