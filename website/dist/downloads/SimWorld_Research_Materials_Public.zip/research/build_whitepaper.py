"""Render the SimWorld manuscript and package reproducibility materials."""
from pathlib import Path
import json, hashlib, zipfile, re, html, shutil
from reportlab.pdfgen import canvas
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                               PageBreak, KeepTogether, Flowable)
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent / 'source' if (WORK.parent / 'source' / 'sim').is_dir() else WORK.parents[1]
OUT = (WORK.parent if ROOT.name == 'source' else ROOT) / 'output' / 'whitepaper'
OUT.mkdir(parents=True, exist_ok=True)
for name, filename in [('Body','times.ttf'), ('BodyBold','timesbd.ttf'), ('BodyItalic','timesi.ttf'),
                       ('Sans','arial.ttf'), ('SansBold','arialbd.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(Path('C:/Windows/Fonts') / filename)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='BodyItalic',boldItalic='BodyBold')
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='SansBold',italic='Sans',boldItalic='SansBold')
PAGE_W,PAGE_H=A4
WIDTH=PAGE_W-108
styles={
 'body':ParagraphStyle('body',fontName='Body',fontSize=11,leading=15,spaceAfter=8,alignment=TA_JUSTIFY),
 'small':ParagraphStyle('small',fontName='Body',fontSize=9.2,leading=12,spaceAfter=7),
 'h1':ParagraphStyle('h1',fontName='SansBold',fontSize=15,leading=19,spaceBefore=4,spaceAfter=14,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='SansBold',fontSize=11.3,leading=15,spaceBefore=12,spaceAfter=6,keepWithNext=True),
 'title':ParagraphStyle('title',fontName='SansBold',fontSize=27,leading=33,spaceAfter=15),
 'subtitle':ParagraphStyle('subtitle',fontName='Body',fontSize=16,leading=21,spaceAfter=18),
 'meta':ParagraphStyle('meta',fontName='Sans',fontSize=9,leading=13,spaceAfter=18),
 'caption':ParagraphStyle('caption',fontName='Sans',fontSize=8.8,leading=11.7,spaceBefore=6,spaceAfter=11),
 'equation':ParagraphStyle('equation',fontName='Body',fontSize=11,leading=16,spaceBefore=5,spaceAfter=10,alignment=TA_CENTER),
 'cell':ParagraphStyle('cell',fontName='Sans',fontSize=8.4,leading=11.2),
 'headcell':ParagraphStyle('headcell',fontName='SansBold',fontSize=8.5,leading=11.2,textColor=colors.white),
 'ref':ParagraphStyle('ref',fontName='Body',fontSize=9.3,leading=12.2,spaceAfter=11),
 'code':ParagraphStyle('code',fontName='Courier',fontSize=8.1,leading=11,spaceAfter=8),
}

class Architecture(Flowable):
    def __init__(self):
        Flowable.__init__(self); self.width=WIDTH; self.height=208
    def draw(self):
        c=self.canv
        groups=[('Implemented reduced model','Quanta and thermal populations | nuclei | capture',142),
                ('Proposed physical and biological models','Atomic structure | chemistry | matter | planet | life',83),
                ('Proposed agents and institutions','Learning | technology | society | monetary systems',24)]
        for title,subtitle,y in groups:
            c.setStrokeColor(colors.HexColor('#87929C')); c.setFillColor(colors.HexColor('#F4F6F8'))
            if y<140: c.setDash(3,2)
            else: c.setDash()
            c.roundRect(7,y,WIDTH-14,46,3,fill=1,stroke=1); c.setDash()
            c.setFillColor(colors.black); c.setFont('SansBold',10)
            c.drawCentredString(WIDTH/2,y+29,title)
            c.setFont('Sans',8.8); c.drawCentredString(WIDTH/2,y+13,subtitle)
        c.setStrokeColor(colors.HexColor('#54697C'))
        for y in [130,71]:
            c.line(WIDTH/2,y+12,WIDTH/2,y-1)
            c.line(WIDTH/2,y-1,WIDTH/2-3,y+4); c.line(WIDTH/2,y-1,WIDTH/2+3,y+4)
        c.setFont('Sans',8.2); c.drawCentredString(WIDTH/2,5,'Shared contracts proposed across levels: conservation, provenance, error and replay')

def paragraph(text,style='body'):
    text=text.replace('<sub>', '<sub rise="2" size="8">').replace('<super>', '<super rise="4" size="8">')
    if style in ('cell','headcell'): text=text.replace('\n','<br/>')
    return Paragraph(text,styles[style])

def table(block):
    rows=block['rows']; widths=[WIDTH*x for x in block['widths']]
    data=[[paragraph(str(v),'headcell' if ri==0 else 'cell') for v in row] for ri,row in enumerate(rows)]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([
      ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#263C50')),
      ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F3F5F7')]),
      ('GRID',(0,0),(-1,-1),0.45,colors.HexColor('#D9D9D9')),
      ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
      ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
      ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
    ]))
    return t

def page_footer(c,doc):
    c.saveState(); c.setFont('Sans',8); c.setFillColor(colors.HexColor('#555555'))
    c.drawString(54,32,'SimWorld research white paper | 29 October 2026')
    c.drawRightString(PAGE_W-54,32,str(doc.page))
    c.restoreState()

class ResearchDocument(SimpleDocTemplate):
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and flowable.style.name in ('h1','title'):
            title=flowable.getPlainText()
            key='outline_'+str(getattr(self,'_outline_count',0))
            self._outline_count=getattr(self,'_outline_count',0)+1
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(title,key,level=0,closed=False)

def render():
    manuscript=json.loads((WORK/'manuscript.json').read_text(encoding='utf-8'))
    story=[]
    for b in manuscript['blocks']:
        kind=b['type']
        if kind=='break': story.append(PageBreak())
        elif kind=='space': story.append(Spacer(1,b['points']))
        elif kind=='table': story.extend([table(b),Spacer(1,7)])
        elif kind=='diagram': story.append(Architecture())
        else: story.append(paragraph(b['text'],kind))
    target=OUT/'SimWorld_Research_White_Paper.pdf'
    doc=ResearchDocument(str(target),pagesize=A4,rightMargin=54,leftMargin=54,
                         topMargin=49,bottomMargin=51,
                         title='SimWorld Research White Paper',
                         author='',subject='Architecture, implementation evidence and validation agenda',
                         pageCompression=1)
    doc.build(story,onFirstPage=page_footer,onLaterPages=page_footer)
    print(str(target))

def snapshot():
    paths=[]
    for pat in ['ROADMAP.md','BUILD0.md','PHASE*.md','requirements.txt','_nightly_ci.xml','sim/*.py','spec/*.md',
                'tests/*.py','tests/*.toml','tests/oracle/*','spikes/*/*.py','spikes/*/*.json',
                'spikes/*/*.csv','_m3run/*','_m4run/*']:
        paths.extend(ROOT.glob(pat))
    paths=sorted({p for p in paths if p.is_file()})
    manifest={'snapshot_date':'2026-10-29','physics_build':'0.1',
              'scope':'Project sources and pre-existing recorded runs used in the white paper',
              'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,
                        'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
    (WORK/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    (WORK/'source_manifest.sha256').write_text(hashlib.sha256((WORK/'source_manifest.json').read_bytes()).hexdigest()+'\n',encoding='utf-8')
    return paths

def package():
    paths=snapshot()
    dst=OUT/'SimWorld_Research_Materials.zip'
    with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,'source/'+p.relative_to(ROOT).as_posix())
        for p in WORK.iterdir():
            if p.is_file() and p.suffix in ['.json','.txt','.xml','.py','.sha256']:
                z.write(p,'research/'+p.name)
        for p in (WORK/'fresh_m4').glob('*'):
            if p.is_file():z.write(p,'research/fresh_m4/'+p.name)
        z.writestr('README.txt',
          'SimWorld research white paper materials, 29 October 2026\n\n'
          'source/: exact source snapshot and archived M3/M4 run data.\n'
          'research/: manuscript, audits, references, fresh run, source SHA-256 manifest.\n'
          'Engine reproduction: cd source; use Python 3.11.9; pip install -r requirements.txt; '
          'python -m pytest -q; python -m sim.demo --seed 42 --ticks 3400 --cells 8 '
          '--probe-cells 2,3 --out reproduced_m4; python -m sim.replay reproduced_m4.\n'
          'Audit diagnostic: from the archive root, run python research/audit_diagnostics.py '
          '--source-root source --output-dir reproduced_audit. This creates fresh evidence.\n'
          'PDF source: manuscript.json holds editable text and tables. Run python '
          'research/build_whitepaper.py to render it using ReportLab and Windows Times New Roman/Arial. '
          'On another operating system, adjust the font paths in the builder. The optional '
          'write_manuscript.py regenerates manuscript.json from its prose source and would replace edits.\n'
          'No new physics or engine fixes are included. Run timings are single-machine observations.\n')
    print(str(dst))

if __name__=='__main__':
    import sys
    if '--package' in sys.argv:package()
    elif '--snapshot' in sys.argv:snapshot()
    else:render()
