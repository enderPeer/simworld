"""Read-only model diagnostics and reproducibility checks for the white paper.

Run from repository root: python tmp/whitepaper/audit_diagnostics.py
For an extracted archive, pass --source-root and --output-dir explicitly.
No simulator source files or existing evidence outputs are modified.
"""
import argparse
import gzip
import hashlib
import json
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument(
    "--source-root", type=Path,
    help="Source snapshot directory containing sim/ and _m4run/. "
         "By default, search the script directory and its parents.")
parser.add_argument(
    "--output-dir", type=Path, default=SCRIPT_DIR / "reproduced_audit",
    help="New or empty directory for generated evidence. Defaults to "
         "reproduced_audit beside this script. Existing evidence is never overwritten.")
args = parser.parse_args()
ROOT = args.source_root
if ROOT is None:
    ROOT = next((candidate for candidate in (SCRIPT_DIR, *SCRIPT_DIR.parents)
                 if (candidate / "sim/demo.py").is_file()
                 and (candidate / "_m4run/summary.json").is_file()), None)
if ROOT is None:
    parser.error("Cannot locate the source snapshot; specify --source-root.")
ROOT = ROOT.resolve()
if not (ROOT / "sim/demo.py").is_file() or not (ROOT / "_m4run/summary.json").is_file():
    parser.error("--source-root must contain sim/demo.py and _m4run/summary.json.")
OUT = args.output_dir.resolve()
if OUT.exists() and (not OUT.is_dir() or any(OUT.iterdir())):
    parser.error("--output-dir must be new or empty; existing evidence will not be overwritten.")
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
import numpy as np
import pytest
from sim import atoms, network, bind, constants as C
from sim.log import EventContext

report = {
    "audit_time_utc": datetime.now(timezone.utc).isoformat(),
    "environment": {"python": sys.version, "executable": sys.executable,
                    "numpy": np.__version__, "pytest": pytest.__version__,
                    "platform": platform.platform()},
    "command": [sys.executable, str(Path(__file__).resolve()),
                "--source-root", str(ROOT), "--output-dir", str(OUT)],
}

# A pure product population cannot access its dissociation channel because
# channel enumeration depends on simultaneous forward-reactant presence.
nuc = network.NucStore(1)
nuc.add(0, 1, 2, 100)
ctx = EventContext(123, mode="off")
before = nuc.counts.copy()
channels = network._rates(nuc, 0, 10.0)
events = sum(network.step(nuc, ctx, t, 0, 10.0) for t in range(100))
report["nuclear_reverse_diagnostic"] = {
    "initial": "100 nuclei (Z=1,A=2), zero protons/neutrons",
    "temperature_mev": 10.0,
    "p_n_capture_channel_is_open": bind.channel_open(1, 1, 0, 1),
    "enumerated_p_n_reverse_channel": any(
        {i, j} == {network.IDX[(1, 1)], network.IDX[(0, 1)]}
        for i, j, *_ in channels),
    "events_all_channels_over_100_ticks": events,
    "remaining_deuterons": int(nuc.counts[network.IDX[(1, 2)], 0]),
    "produced_protons": int(nuc.counts[network.IDX[(1, 1)], 0]),
    "produced_neutrons": int(nuc.counts[network.IDX[(0, 1)], 0]),
    "meaning": "Pure product cannot dissociate through absent forward reactants; other channels may fire.",
}

# Fully neutral hydrogen has no available channel even when the code's
# own equilibrium helper predicts a substantial free-electron fraction.
nuc = network.NucStore(1)
nuc.add(0, 1, 1, 100)
atom = atoms.AtomStore(1)
atom.captured[0, network.IDX[(1, 1)]] = 100
temp = atoms.T_GATE / 1.2
ctx = EventContext(123, mode="off")
events = sum(atoms.step(atom, nuc, ctx, t, 0, temp) for t in range(1000))
report["atomic_absorbing_diagnostic"] = {
    "initial": "100 neutral hydrogen nuclei, 100 captured electrons",
    "temperature_mev": temp,
    "ticks": 1000,
    "events": events,
    "final_free_electrons": atom.free_electrons(nuc.counts, 0),
    "model_saha_x_e": atoms.saha_x_e(100, temp),
    "meaning": "Fully captured species are excluded, so neutral state is absorbing despite positive modeled Saha ionization.",
}

ctx = EventContext(42, mode="off")
a = ctx.draws(0, "condense", cell=0, payload=[5.0], n=10)
b = ctx.draws(0, "condense", cell=0, payload=[8.0], n=16)
report["rng_reuse_diagnostic"] = {
    "first_n": 10, "second_n": 16,
    "distinct_payloads": True,
    "identical_prefix": bool(np.array_equal(a, b[:10])),
    "meaning": "Repeated same tick/kind/cell/sub calls restart stream regardless of payload; species calls share prefixes.",
}

commands = [
    [sys.executable, "-m", "sim.demo", "--seed", "42", "--ticks", "3400",
     "--cells", "8", "--probe-cells", "2,3", "--out", str(OUT / "fresh_m4")],
    [sys.executable, "-m", "sim.replay", str(OUT / "fresh_m4")],
]
report["runs"] = []
for cmd in commands:
    start = time.perf_counter()
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    report["runs"].append({"command": cmd, "seconds": time.perf_counter()-start,
                           "returncode": result.returncode,
                           "stdout": result.stdout, "stderr": result.stderr})

fresh = json.loads((OUT / "fresh_m4/summary.json").read_text())
snapshot = json.loads((ROOT / "_m4run/summary.json").read_text())
def raw_digest(path):
    with gzip.open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()
report["snapshot_comparison"] = {
    "summary_identical": fresh == snapshot,
    "summary_differences": {k: [snapshot.get(k), fresh.get(k)]
                             for k in sorted(set(snapshot) | set(fresh))
                             if snapshot.get(k) != fresh.get(k)},
    "fresh_uncompressed_log_sha256": raw_digest(OUT / "fresh_m4/run.jsonl.gz"),
    "snapshot_uncompressed_log_sha256": raw_digest(ROOT / "_m4run/run.jsonl.gz"),
    "hashes_identical": (OUT / "fresh_m4/hashes.json").read_bytes() == (ROOT / "_m4run/hashes.json").read_bytes(),
    "summary": fresh,
}
(OUT / "audit_diagnostics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
